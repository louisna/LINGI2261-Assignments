import java.util.ArrayList;

public class KOpt extends LocalSearch{

    private int K;

    public KOpt(int[][] dist, ArrayList<Integer> tour, int K) {
        super(dist, tour);
        this.K = K;
    }

    @Override
    public boolean iteration() {
        boolean found = false;
        for (int i = 0; i < nNodes; i++) {
            if (kOptFrom(i)) {
                found = true;
            }
        }
        return found;
    }

    public boolean kOptFrom(int i) {
        save();
        int cumulatedDelta = 0;
        int bestCumulatedDelta = cumulatedDelta;
        int bestK = 0;
        int k = 0;
        int prev = -1;
        do {
            k++;
            double bestDelta = Integer.MAX_VALUE;
            int bestj = -1;
            for (int j = 0; j < nNodes; j++) {
                int  dist = Math.abs(i-j);
                if (1 < dist && dist < nNodes-1) {
                    double delta = deltaTwoOpt(i, j);
                    if (delta < bestDelta) {
                        bestDelta = delta;
                        bestj = j;
                    }
                }
            }
            prev = bestj;
            twoOpt(i, bestj);
            cumulatedDelta += bestDelta;
            if (cumulatedDelta < bestCumulatedDelta) {
                bestCumulatedDelta = cumulatedDelta;
                bestK = k;
                save();
            }
        } while (k < K && cumulatedDelta < 0);
        restore();
        return bestCumulatedDelta < 0;
    }
}
