import java.util.ArrayList;

abstract class LocalSearch {
    int nNodes;
    private ArrayList<Integer> tour = new ArrayList<>();
    private ArrayList<Integer> savedTour = new ArrayList<>();
    private int[][] dist;

    public LocalSearch(int[][] dist, ArrayList<Integer> tour) {
        nNodes = tour.size()-1;
        this.dist = dist;
        this.tour.addAll(tour);
        this.savedTour.clear();
        this.savedTour.addAll(tour);
    }

    public void save() {
        this.savedTour.clear();
        this.savedTour.addAll(tour);
    }

    public void restore() {
        this.tour.clear();
        this.tour.addAll(savedTour);
    }

    public double deltaTwoOpt(int left, int right) {
        double distLeft = dist[tour.get(left)][tour.get(left+1)];
        double distRight = dist[tour.get(right)][tour.get(right+1)];
        double newDistLeft = dist[tour.get(left)][tour.get(right)];
        double newDistRight = dist[tour.get(left+1)][tour.get(right+1)];
        return newDistLeft + newDistRight - distLeft - distRight;
    }

    public void twoOpt(int i, int j) {
        int left = Math.min(i, j);
        int right = Math.max(i, j);
        assert(left >= 0 && right < nNodes);
        int k = 0;
        int n = (right - left + 1) / 2;
        while (k < n) {
            int tmp = tour.get(left + 1 + k);
            tour.set(left + k + 1, tour.get(right - k));
            tour.set(right - k, tmp);
            k++;
        }
    }

    public int distance(){
        int distance = 0;
        for(int i=1; i<tour.size(); i++){
            distance += dist[tour.get(i-1)][tour.get(i)];
        }
        return distance;
    }

    public abstract boolean iteration();

    public ArrayList<Integer> optimize() {
        int iter = 0;
        //long t0 = System.currentTimeMillis();
        boolean improved = false;
        do {
            improved = iteration();
            iter++;
        } while (improved);
        // System.out.println(tour.size());
        //long t1 = System.currentTimeMillis();
        //tour.remove(tour.size() - 1);
        return tour;

    }
}
