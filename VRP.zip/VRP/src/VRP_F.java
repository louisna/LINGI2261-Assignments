import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class VRP_F {

    private static int n;
    private static int W;
    static int[] d;
    public static int[][] dist;
    private static Random rnd = new Random(3);
    private static final long maxTime = 240000;
    private static boolean greedyInit = false;
    private static final int nbBest = 10;
    private static final int MAXNEIG = 100;
    private static final int optK = 7;
    private static final int MAXITER = 100;

    public static void main(String[] args) {
        try (Scanner scan = new Scanner(new File(args[0])).useLocale(Locale.US)) {
        //try (Scanner scan = new Scanner(new File("/Users/louisnavarre/Downloads/instanceC.txt")).useLocale(Locale.US)) {

            n = scan.nextInt();
            int k = scan.nextInt();
            W = scan.nextInt();

            double[] x = new double[n];
            double[] y = new double[n];
            d = new int[n];

            for (int i = 0; i < n; i++) {
                d[i] = scan.nextInt();
                x[i] = scan.nextDouble();
                y[i] = scan.nextDouble();
            }

            dist = Distances.compute(x, y);

            // Init separation of the tours
            ArrayList<ArrayList<Integer>> tours;
            if (greedyInit) {
                tours = greedy();
            } else {
                tours = ClarkAndWright();
            }

            // Best solution of the problem
            ArrayList<ArrayList<Integer>> bestSolution = new ArrayList<>();
            int bestValue = 0;

            // Set containing the nbBest's solutions
            ArrayList<ArrayList<ArrayList<Integer>>> bestSet = new ArrayList<>();

            // Init the first best solution
            for (ArrayList<Integer> tour : tours) {
                LocalSearch solution = new KOpt(dist, tour, optK);
                tour = solution.optimize();
                bestSolution.add(tour);
                bestValue += solution.distance();
            }

            bestSet.add(bestSolution);

            int[][] tabuSwaps = new int[n][n];
            int[]   tabuMoves = new int[n];

            int iteration = 0;
            long timeBegin = System.currentTimeMillis();

            while (iteration < MAXITER || System.currentTimeMillis() - timeBegin < maxTime) {
                //System.out.println();
                //System.out.print("Ewa ma best value à iteration " + iteration + ": " + bestValue + " ");
                iteration++;
                int bestIterationValue = Integer.MAX_VALUE;

                // Restart every 1000 iterations
                if (iteration % 1000 == 0) {
                    // Select randomly a tour from the best tours of the sets
                    int random = Math.abs(rnd.nextInt()) % bestSet.size();
                    tours = new ArrayList<>(bestSet.get(random));
                }

                // Best successor
                ArrayList<ArrayList<Integer>> bestNext = deepCopy(tours);
                // Copy of the tour
                ArrayList<ArrayList<Integer>> toursCopy;
                // Contains the best neighbors
                ArrayList<ArrayList<ArrayList<Integer>>> neighb = new ArrayList<>();

                // Generate all possible next tours from moves
                for (int i = 0; i < tours.size(); i++) {
                    ArrayList<Integer> tourA = tours.get(i);
                    for (int index = 1; index < tourA.size()-1; index++) {
                        for (int j = i; j < tours.size(); j++) {
                            // If the move is tabu we skip it
                            if (tabuMoves[tours.get(i).get(index)] > iteration) continue;
                            toursCopy = deepCopy(tours);
                            // If we can move the item
                            if(moveItem(toursCopy.get(i), toursCopy.get(j), index)) {
                                // Tabu
                                tabuMoves[tours.get(i).get(index)] = iteration + 1 + (rnd.nextInt() % n);

                                int totalDistance = 0;
                                ArrayList<ArrayList<Integer>> sol = new ArrayList<>();

                                for (ArrayList<Integer> tour : toursCopy) {
                                    LocalSearch solution = new KOpt(dist, tour, optK);
                                    tour = solution.optimize();
                                    sol.add(tour);
                                    totalDistance += solution.distance();
                                }

                                if (totalDistance < bestValue*1.4) {
                                    if (neighb.size() > MAXNEIG) {
                                        neighb.remove(Math.abs(rnd.nextInt()) % neighb.size());
                                        neighb.add(sol);
                                    } else {
                                        neighb.add(sol);
                                    }
                                }
                            }
                        }
                    }
                }

                // Generate all possible next tours from swaps
                for (int i = 0; i < tours.size(); i++) {
                    ArrayList<Integer> tourA = tours.get(i);
                    for (int index = 1; index < tourA.size()-1; index++) {
                        for (int j = i; j < tours.size(); j++) {
                            for (int indexB = 1; indexB < tours.get(j).size()-1; indexB++) {
                                // If the move is tabu we skip it
                                if (tabuSwaps[tours.get(i).get(index)][tours.get(j).get(indexB)] > iteration) continue;
                                toursCopy = deepCopy(tours);
                                // If we can swap the items
                                if(swapItems(toursCopy.get(i), toursCopy.get(j), index, indexB)) {
                                    tabuSwaps[tours.get(i).get(index)][tours.get(j).get(indexB)] = iteration + 1 + (rnd.nextInt() % n );
                                    tabuSwaps[tours.get(j).get(indexB)][tours.get(i).get(index)] = iteration + 1 + (rnd.nextInt() % n );


                                    int totalDistance = 0;
                                    ArrayList<ArrayList<Integer>> sol = new ArrayList<>();

                                    for (ArrayList<Integer> tour : toursCopy) {
                                        LocalSearch solution = new KOpt(dist, tour, optK);
                                        tour = solution.optimize();
                                        sol.add(tour);
                                        totalDistance += solution.distance();
                                    }

                                    if (totalDistance < bestValue*1.4) {
                                        if (neighb.size() > MAXNEIG) {
                                            neighb.remove(Math.abs(rnd.nextInt()) % neighb.size());
                                            neighb.add(sol);
                                        } else {
                                            neighb.add(sol);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                //System.out.print(neighb.size() + " ");
                if (neighb.size() == 0) {
                    // No neigh
                    int random = Math.abs(rnd.nextInt()) % bestSet.size();
                    tours = new ArrayList<>(bestSet.get(random));
                    continue;
                }

                int bestNeighValue = Integer.MAX_VALUE;
                ArrayList<ArrayList<Integer>> bestNeigh = new ArrayList<>();

                for (ArrayList<ArrayList<Integer>> path: neighb) {
                    int dn = 0;
                    for (ArrayList<Integer> tour: path) {
                        LocalSearch sol = new KOpt(dist, tour, 7);
                        sol.optimize();
                        dn += sol.distance();
                    }

                    if (dn < bestNeighValue) {
                        bestNeighValue = dn;
                        bestNeigh = deepCopy(path);
                    }

                }

                if (bestNeighValue > bestValue*1.3) {
                    int random = Math.abs(rnd.nextInt()) % bestSet.size();
                    tours = new ArrayList<>(bestSet.get(random));
                    continue;
                }

                //System.out.print(bestNeighValue);

                if (bestNeighValue < bestValue) {
                    bestSolution = deepCopy(bestNeigh);
                    bestValue = bestNeighValue;
                    if (bestSet.size() >= nbBest) {
                        bestSet.remove(0);
                    }
                    bestSet.add(bestNeigh);
                }
                tours = bestNeigh;
            }

            System.out.println(bestValue);
            int trucksLeft = k - bestSolution.size();
            for (int i = 0; i < trucksLeft; i++) {
                System.out.println("0 0");
            }


            for (ArrayList<Integer> a: bestSolution) {
                for (int i: a) {
                    System.out.print(i + " ");
                }
                System.out.println();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static class Distances {

        /**
         * Compute the distance matrix.
         *
         * @param x
         *            an array of x coordinates.
         * @param y
         *            an array of y coordinates.
         * @return the normalized distance matrix corresponding to the given
         *         coordinates.
         */
        public static int[][] compute(double[] x, double[] y) {
            assert (x.length == y.length);
            int n = x.length;
            int[][] distances = new int[n][n];
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < i; j++) {
                    double dx = x[i] - x[j];
                    double dy = y[i] - y[j];
                    double dist = Math.sqrt(dx * dx + dy * dy);
                    int distNorm = (int) Math.round(dist);
                    distances[i][j] = distNorm;
                    distances[j][i] = distNorm;
                }
            }
            return distances;
        }
    }

    /**
     *
     * @return an initial solution of the VRP using the Clark & Wright method
     */
    private static ArrayList<ArrayList<Integer>> ClarkAndWright() {
        PriorityQueue<Edge> pq = new PriorityQueue<Edge>((Comparator.comparing(Edge::getInverseDist)));
        for (int i = 1; i < n; i++) {
            for (int j = 1; j < i; j++) {
                pq.add(new Edge(i, j,  dist[i][0] + dist[0][j] - dist[j][i]));
            }
        }
        int[] parents = new int[n];
        ArrayList<Integer>[] tours = new ArrayList[n];
        for (int i = 1; i < n; i++) {
            ArrayList<Integer> tour = new ArrayList<>();
            tour.add(i);
            tours[i] = tour;
        }
        for (int i = 1;  i < n; i++) {
            parents[i] = i;
        }

        while (!pq.isEmpty()) {
            Edge e = pq.remove();
            ArrayList<Integer> tourI = tours[parents[e.i]];
            ArrayList<Integer> tourJ = tours[parents[e.j]];
            if (tourI != tourJ && tourI.size() > 0 && tourJ.size() > 0 && pathCost(tourI) + pathCost(tourJ) <= W &&
                    notInTheMiddle(tourI, e.i) && notInTheMiddle(tourJ, e.j)) {
                tourI.addAll(tourJ);
                LocalSearch sol = new KOpt(dist, tourI, optK);
                tours[parents[e.i]] = sol.optimize();
                tourJ.clear();
                parents[e.j] = parents[e.i];
            }
        }

        ArrayList<ArrayList<Integer>> toursAL = new ArrayList<>();

        for (int i = 1; i < n; i++) {
            if (parents[i] == i && tours[i].size() > 0) {
                toursAL.add(tours[i]);
            }
        }

        // Add first depot
        for (ArrayList<Integer> path: toursAL) {
            path.add(0, 0);
            path.add(0);
        }

        return toursAL;
    }

    /**
     *
     * @param path: the path
     * @return the cost (in term of demand) of the clients in the path
     */
    private static int pathCost(ArrayList<Integer> path) {
        int cost = 0;
        for (int i: path)
            cost += d[i];
        return cost;
    }

    /**
     *
     * @param path the path
     * @param client the client in the path
     * @return true if the client is not in the middle of the path, i.e. it is the first of last client of the tour
     */
    private static boolean notInTheMiddle(ArrayList<Integer> path, int client) {
        // Maybe make a function for first and a second for last to be able to correctly merge the paths
        return path.get(0) == client || path.get(path.size()-1) == client; // First or last
    }

    /**
     *
     * @param base the total tours to be clones
     * @return a complete copy of base
     */
    private static ArrayList<ArrayList<Integer>> deepCopy(ArrayList<ArrayList<Integer>> base) {
        ArrayList<ArrayList<Integer>> copy = new ArrayList<>();
        for (ArrayList<Integer> c: base) {
            copy.add(new ArrayList<>(c));
        }
        return copy;
    }

    /**
     *
     * @param pathA pathB
     * @param pathB pathA
     * @param a index of the object in pathA
     * @param b index of the object in pathB
     * @return true if item at index a from pathA can be swapped with item at index b from pathB
     */
    private static boolean swapItems(ArrayList<Integer> pathA, ArrayList<Integer> pathB, int a, int b) {
        int itemA = pathA.get(a);
        int itemB = pathB.get(b);
        int costAb = pathCost(pathA) - d[itemA] + d[itemB];
        int costBa = pathCost(pathB) - d[itemB] + d[itemA];
        if ((costAb <= W && costBa <= W)) {

            pathA.set(a, itemB);
            pathB.set(b, itemA);
            return true;
        }
        return false;
    }

    /**
     *
     * @param from the path from
     * @param to the path to
     * @param index the index of the item in 'from' of the object to be moved
     * @return true if the object can be moved
     */
    private static boolean moveItem(ArrayList<Integer> from, ArrayList<Integer> to, int index) {
        int item = from.get(index);
        int costToWith = pathCost(to) + d[item];
        if (costToWith <= W) {
            from.remove(index);
            to.remove(to.size()-1);
            to.add(item);
            to.add(0);
            return true;
        }
        return false;
    }

    /**
     *
     * @return An initialization of the VRP problem using a greedy method: closest clients
     */
    private static ArrayList<ArrayList<Integer>> greedy() {
        ArrayList<ArrayList<Integer>> tours = new ArrayList<>();

        boolean[] taken = new boolean[n];

        ArrayList<Integer> current = new ArrayList<>();
        // Node 0 is the source
        int total = 1;
        int node = 1;
        taken[node] = true;
        int currentDemand = d[node];
        current.add(node);
        while (total < n-1) {
            int closer = -1;
            int closer_value = Integer.MAX_VALUE;

            int closer_in = -1;
            int closer_in_value = Integer.MAX_VALUE;
            for (int i = 1; i < n; i++) {
                if (i != node && dist[node][i] < closer_value && !taken[i]) {
                    closer_value = dist[node][i];
                    closer = i;
                }
                if (i != node && dist[node][i] < closer_in_value && !taken[i] && currentDemand + d[i] <= W) {
                    closer_in_value = dist[node][i];
                    closer_in = i;
                }
            }
            // We have the closer friend
            total++;
            if (currentDemand + d[closer] <= W) {
                current.add(closer);
                currentDemand += d[closer];
                taken[closer] = true;
            } else if (closer_in != -1) {
                current.add(closer_in);
                currentDemand += d[closer_in];
                taken[closer_in] = true;
            } else {
                current.add(0, 0);
                current.add(0);
                tours.add(current);
                current = new ArrayList<>();
                current.add(closer);
                currentDemand = d[closer];
                taken[closer] = true;
            }
            node = closer;
        }
        current.add(0, 0);
        current.add(0);
        tours.add(current);
        return tours;
    }

}