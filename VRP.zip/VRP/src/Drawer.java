import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Drawer extends JPanel {

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g;

        Dimension size = getSize();
        int w = size.width ;
        int h = size.height;

        Color[] colors = new Color[]{Color.black, Color.gray, Color.green, Color.magenta, Color.YELLOW, Color.pink, Color.orange, Color.red, Color.darkGray, Color.cyan, Color.yellow, Color.GREEN, Color.black, Color.green};

        int t = 0;
        for (ArrayList<Integer> path: VRP_Second.ssss) {
            g2d.setColor(colors[t++]);
            for (int i = 0; i < path.size()-1; i++) {
                g2d.drawLine((int)VRP_Second.x[path.get(i)]*4 + 350, (int)VRP_Second.y[path.get(i)]*4 + 450, (int)VRP_Second.x[path.get(i+1)]*4 + 350, (int)VRP_Second.y[path.get(i+1)]*4 + 450);
                g2d.drawOval((int)VRP_Second.x[path.get(i)]*4 + 350, (int)VRP_Second.y[path.get(i)]*4 + 450, 4, 4);
            }
        }

    }

    public static void drawPoints() {
        Drawer points = new Drawer();
        JFrame frame = new JFrame("Vehicle Routing Problem");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(points);
        frame.setSize(1000, 1000);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

}