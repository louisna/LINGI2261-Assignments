import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class VRP_OP {

    public static int n, k, W;
    public static double[] x, y;
    public static int[] d;
    public static int[][] dist;

    public static void main(String[] args) {
        try (Scanner scan = new Scanner(new File(args[0])).useLocale(Locale.US)) {
        //try (Scanner scan = new Scanner(new File("/Users/louisnavarre/Downloads/instanceB.txt")).useLocale(Locale.US)) {

            n = scan.nextInt();
            k = scan.nextInt();
            W = scan.nextInt();

            x = new double[n];
            y = new double[n];
            d = new int[n];

            for (int i = 0; i < n; i++) {
                d[i] = scan.nextInt();
                x[i] = scan.nextDouble();
                y[i] = scan.nextDouble();
            }

            dist = Distances.compute(x, y);

            ArrayList<ArrayList<Integer>> tours = ClarkAndWright();
            ArrayList<ArrayList<Integer>> bestSolution = deepCopy(tours);

            int bestValue = Integer.MAX_VALUE;

            for (int j = 0; j < 100; j++) {

                int totalDistance = 0;
                ArrayList<ArrayList<Integer>> sol = new ArrayList<>();

                for (ArrayList<Integer> tour: tours) {
                    LocalSearch solution = new KOpt(dist, tour, 5);
                    tour = solution.optimize();
                    sol.add(tour);
                    totalDistance += solution.distance();
                }
                /*
                for (ArrayList<Integer> a: sol) {
                    int i;
                    for (i = 0; i < a.size()-1; i++) {
                        totalDistance += dist[a.get(i)][a.get(i+1)];
                    }
                    totalDistance += dist[a.get(i)][a.get(0)];
                }
                */

                if (totalDistance < bestValue) {
                    bestSolution = sol;
                    bestValue = totalDistance;
                }

                int swapA = randomInt(tours.size());
                int swapB = randomInt(tours.size());

                if (swapA != swapB) {
                    int swapAItem = randomInt(tours.get(swapA).size()-1);
                    int swapBItem = randomInt(tours.get(swapB).size()-1);
                    swapItems(tours.get(swapA), tours.get(swapB), swapAItem, swapBItem);
                }

            }
            /*
            if (trucksLeft < 0) {
                // We used more trucks than we could
                int toMuchTrucks = -trucksLeft;
                for (int i = 0; i < toMuchTrucks; i++) {
                    for (int j: sol.get(i)) {
                        if (j == 0) continue;
                        sol.get(sol.size()-1-i).add(j);
                    }
                    sol.get(sol.size()-1-i).add(0);
                }
                ArrayList<ArrayList<Integer>> sol2 = new ArrayList<>();
                for (int i = toMuchTrucks; i < sol.size(); i++) {
                    //System.out.println(sol.get(i).toArray());
                    sol2.add(sol.get(i));
                }
                sol = sol2;
            }
            */
            System.out.println(bestValue);
            int trucksLeft = k - bestSolution.size();
            for (int i = 0; i < trucksLeft; i++) {
                System.out.println("0 0");
            }


            for (ArrayList<Integer> a: bestSolution) {
                for (int i: a) {
                    System.out.print(i + " ");
                }
                System.out.println();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static class Distances {

        /**
         * Compute the distance matrix.
         *
         * @param x
         *            an array of x coordinates.
         * @param y
         *            an array of y coordinates.
         * @return the normalized distance matrix corresponding to the given
         *         coordinates.
         */
        public static int[][] compute(double[] x, double[] y) {
            assert (x.length == y.length);
            int n = x.length;
            int[][] distances = new int[n][n];
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < i; j++) {
                    double dx = x[i] - x[j];
                    double dy = y[i] - y[j];
                    double dist = Math.sqrt(dx * dx + dy * dy);
                    int distNorm = (int) Math.round(dist);
                    distances[i][j] = distNorm;
                    distances[j][i] = distNorm;
                }
            }
            return distances;
        }
    }

    public static ArrayList<ArrayList<Integer>> ClarkAndWright() {
        PriorityQueue<Edge> pq = new PriorityQueue<Edge>(Comparator.comparing(i -> -i.dist));
        for (int i = 1; i < n; i++) {
            for (int j = 1; j < i; j++) {
                pq.add(new Edge(i, j,  dist[i][0] + dist[0][j] - dist[j][i]));
            }
        }
        int[] parents = new int[n];
        ArrayList<Integer>[] tours = new ArrayList[n];
        for (int i = 1; i < n; i++) {
            ArrayList<Integer> tour = new ArrayList<>();
            tour.add(i);
            tours[i] = tour;
        }
        for (int i = 1;  i < n; i++) {
            parents[i] = i;
        }

        while (!pq.isEmpty()) {
            Edge e = pq.remove();
            ArrayList<Integer> tourI = tours[parents[e.i]];
            ArrayList<Integer> tourJ = tours[parents[e.j]];
            if (tourI != tourJ && tourI.size() > 0 && tourJ.size() > 0 && pathCost(tourI) + pathCost(tourJ) <= W &&
            notInTheMiddle(tourI, e.i) && notInTheMiddle(tourJ, e.j)) {
                tourI.addAll(tourJ);
                tourJ.clear();
                parents[e.j] = parents[e.i];
            }
        }

        ArrayList<ArrayList<Integer>> toursAL = new ArrayList<>();

        for (int i = 1; i < n; i++) {
            if (parents[i] == i && tours[i].size() > 0) {
                toursAL.add(tours[i]);
            }
        }

        // Add first depot
        for (ArrayList<Integer> path: toursAL) {
            path.add(0, 0);
            path.add(0);
        }

        return toursAL;
    }

    public static int pathCost(ArrayList<Integer> path) {
        int cost = 0;
        for (int i: path)
            cost += d[i];
        return cost;
    }

    public static boolean notInTheMiddle(ArrayList<Integer> path, int client) {
        // Maybe make a function for first and a second for last to be able to correctly merge the paths
        return path.get(0) == client || path.get(path.size()-1) == client; // First or last
    }

    public static ArrayList<ArrayList<Integer>> deepCopy(ArrayList<ArrayList<Integer>> base) {
        ArrayList<ArrayList<Integer>> copy = new ArrayList<>();
        for (ArrayList<Integer> c: base) {
            copy.add(new ArrayList<>(c));
        }
        return copy;
    }

    public static int randomInt(int size) {
        Random rnd = new Random();
        return rnd.nextInt(size - 1) + 1;
    }

    public static void swapItems(ArrayList<Integer> pathA, ArrayList<Integer> pathB, int a, int b) {
        int costAb = pathCost(pathA) - d[a] + d[b];
        int costBa = pathCost(pathB) - d[b] + d[a];
        if (costAb <= W && costBa <= W) {
            int itemA = pathA.get(a);
            int itemB = pathB.get(b);
            pathA.remove(a);
            pathB.remove(b);
            pathA.add(itemA);
            pathB.add(itemB);
        }
    }

}

/*
public static ArrayList<ArrayList<Integer>> sweep(double initialAngle) {
        PriorityQueue<Integer> pq = new PriorityQueue<>(Comparator.comparing(i -> -((Math.atan2(y[i]+0.000001, x[i]) + initialAngle) % (2*Math.PI))));
        for (int i = 1; i < n; i++) {
            pq.add(i);
        }
        ArrayList<ArrayList<Integer>> ret = new ArrayList<>();
        ArrayList<Integer> current = new ArrayList<>();
        while (!pq.isEmpty()) {
            int i = pq.poll();
            if (pathCost(current) + d[i] <= W) {
                current.add(i);
            } else {
                ret.add(current);
                current = new ArrayList<>();
                current.add(i);
            }
        }
        ret.add(current);
        for (ArrayList<Integer> path: ret) {
            path.add(0, 0);
        }
        return ret;
    }
 */