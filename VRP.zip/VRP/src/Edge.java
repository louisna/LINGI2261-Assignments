public class Edge {
    int i;
    int j;
    int dist;

    public Edge(int i, int j, int dist){
        this.i = i;
        this.j = j;
        this.dist = dist;
    }

    public int getInverseDist() {
        return -dist;
    }

    public int additionnalDemand() {
        return VRP.d[j];
    }
}
